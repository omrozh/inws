password=""
username=""

clear

if [ -f ~/usernamecache.txt ]
    then
    echo "InStore Auto Login initiated."
    password=$(cat ~/passwordcache.txt)
    username=$(cat ~/usernamecache.txt)
fi

inws(){
    if [ "$1" = "download" ]
        then echo "Download"
        ~/inws.app/Contents/MacOS/push download $2 $3 $username $password
    fi
    if [ "$1" = "upload" ]
        then echo "Upload"
        ~/inws.app/Contents/MacOS/push upload $2 $username $password
    fi
    if [ "$1" = "list" ]
        then ~/inws.app/Contents/MacOS/push list $username $password
    fi
    if [ "$1" = "search" ]
        then ~/inws.app/Contents/MacOS/push search $2 $username $password
    fi
    if [ "$1" = "delete" ]
        then ~/inws.app/Contents/MacOS/push delete $2 $username $password
    fi
    if [ "$1" = "createAccount" ]
        then echo "Usernames should not contain special characters or non English letters!"
        ~/inws.app/Contents/MacOS/push createAccount $2 $3
    fi
    if [ "$1" = "createAccount" ]
        then clear
        instore login $2 $3
    fi
    if [ "$1" = "login" ]
        then clear

        password=$3
        username=$2

        echo $username >>usernamecache.txt
        echo $password >>passwordcache.txt


        echo "Logged in as $username"
    fi
    if [ "$1" = "addOwner" ]
        then ~/inws.app/Contents/MacOS/push addOwner $2 $3 $username $password
        echo "Adding new owner"
    fi
}
