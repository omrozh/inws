password=""
username=""

clear

if [ -f ~/usernamecache.txt ]
    then
    echo "InWS Auto Login initiated."
    password=$(cat ~/passwordcache.txt)
    username=$(cat ~/usernamecache.txt)
fi

inws(){
    if [ "$1" = "download" ]
        then echo "Download"
        ~/inws.app/Contents/MacOS/inws download $2 $3 $username $password
    fi
    if [ "$1" = "upload" ]
        then echo "Upload"
        ~/inws.app/Contents/MacOS/inws upload $2 $username $password
    fi
    if [ "$1" = "list" ]
        then ~/inws.app/Contents/MacOS/inws list $username $password
    fi
    if [ "$1" = "search" ]
        then ~/inws.app/Contents/MacOS/inws search $2 $username $password
    fi
    if [ "$1" = "delete" ]
        then ~/inws.app/Contents/MacOS/inws delete $2 $username $password
    fi
    if [ "$1" = "createAccount" ]
        then echo "Usernames should not contain special characters or non English letters!"
        ~/inws.app/Contents/MacOS/inws createAccount $2 $3
    fi
    if [ "$1" = "createAccount" ]
        then clear
        inws login $2 $3
    fi
    if [ "$1" = "login" ]
        then clear
        if [ -f ~/usernamecache.txt ]
            then
            rm ~/usernamecache.txt
            rm ~/passwordcache.txt
        fi


        password=$3
        username=$2

        echo $username >>usernamecache.txt
        echo $password >>passwordcache.txt


        echo "Logged in as $username"
    fi
    if [ "$1" = "addOwner" ]
        then ~/inws.app/Contents/MacOS/inws addOwner $2 $3 $username $password
        echo "Adding new owner"
    fi
}
